#!/usr/bin/env python3

from brain_games.games.game import prime_num


def main():
    prime_num()


if __name__ == '__main__':
    main()